package com.zsz;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;

import java.net.InetAddress;
import java.net.UnknownHostException;

@SpringBootApplication
@Slf4j
public class ZhxyApplication {

    public static void main(String[] args) throws UnknownHostException {
        log.info("服务开始启动~");
        ConfigurableApplicationContext applicationContext = SpringApplication.run(ZhxyApplication.class, args);
        ConfigurableEnvironment env = applicationContext.getEnvironment();


        log.info("-------服务启动完成:{}-------", InetAddress.getLocalHost().getHostAddress());
    }

}
