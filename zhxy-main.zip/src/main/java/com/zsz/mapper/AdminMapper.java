package com.zsz.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zsz.pojo.Admin;
import org.springframework.stereotype.Repository;

@Repository
public interface AdminMapper extends BaseMapper<Admin> {
}
