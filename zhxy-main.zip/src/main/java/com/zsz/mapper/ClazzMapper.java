package com.zsz.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zsz.pojo.Clazz;
import org.springframework.stereotype.Repository;

@Repository
public interface ClazzMapper extends BaseMapper<Clazz> {
}
