package com.zsz.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zsz.pojo.Student;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentMapper extends BaseMapper<Student> {
}
