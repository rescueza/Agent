package com.zsz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZhxyApplicationTests {

    @Test
    void contextLoads() {

    }

    public static void main(String[] args) {
        String environment = System.getProperty("os.name").toLowerCase();
        System.out.println(environment);
    }

}
